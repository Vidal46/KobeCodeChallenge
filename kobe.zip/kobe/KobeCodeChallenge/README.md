# KobeCodeChallenge
Android native application created for the kobe.io mobile challenge
